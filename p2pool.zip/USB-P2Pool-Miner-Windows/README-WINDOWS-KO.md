# Windows USB용 Monero P2Pool

## 실행

1. ZIP을 100GB USB에 압축 해제합니다.
2. `START-P2POOL-WINDOWS.bat`를 더블클릭합니다.
3. 첫 실행 때 CPU 해시레이트와 Main/Mini 실시간 지표를 계산해 선택합니다.
4. Gupax가 공개 P2Pool 호환 노드를 자동 검색하고 빠른 노드를 선택합니다.
5. Gupax, P2Pool, XMRig를 한 번 실행합니다.

공개 노드는 고정 목록이 아니라 실행할 때마다 자동으로 검색합니다. 자세한 내용은 `NODE-MANAGEMENT-KO.md`를 참고하세요.

- 지갑 주소: 설정 완료
- 공개 노드 자동 검색: 활성화
- Main/Mini 자동 선택: 실시간 share 난이도·예상 share 시간·PPLNS 조건 기반
- 자동 재시작: 사용하지 않음
- Windows x64: XMRig 6.26.0 / P2Pool 4.18.1 / Gupax 2.0.1

`START-P2POOL-WINDOWS.bat`를 실행하면 채굴이 한 번 시작됩니다. 선택 결과는 `chain-selection.log`에 저장됩니다. 중지하려면 실행된 창을 닫거나 `Ctrl+C`를 누릅니다.
