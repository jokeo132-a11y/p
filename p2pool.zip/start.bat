@echo off
setlocal EnableExtensions EnableDelayedExpansion
pushd "%~dp0"

set "BASE=%~dp0"
set "DATA=%BASE%p2pool-data"
set "LOG=%DATA%\p2pool.log"
set "WALLET=42oyVMt9WTyVBNSY81ArA4NotCt7hKxxXQMk32e1tS6oTaxVZv2Y72E83JLV3xBF2e28uF3YiuAYNizNZTACBq1JHfzwUHu"

if not exist "%BASE%p2pool.exe" goto MISSING_P2POOL
if not exist "%BASE%xmrig.exe" goto MISSING_XMRIG
if not exist "%BASE%config.json" goto MISSING_CONFIG
if not exist "%DATA%" mkdir "%DATA%"

rem Avoid a second P2Pool instance on normal Windows. Wine may not expose tasklist correctly.
tasklist /FI "IMAGENAME eq p2pool.exe" 2>nul | find /I "p2pool.exe" >nul
if not errorlevel 1 goto ALREADY_RUNNING

rem Remove only the old log marker. Keep P2Pool cache and peer data.
if exist "%LOG%" del /q "%LOG%" >nul 2>&1
if exist "%LOG%" goto LOG_LOCKED

echo Starting P2Pool Mini...
rem Use START without /D; /D is misinterpreted by Wine 9.
start "P2Pool Mini" /b "%BASE%p2pool.exe" --data-dir "%DATA%" --host node.sethforprivacy.com --rpc-port 18089 --zmq-port 18084 --wallet "%WALLET%" --mini --stratum 127.0.0.1:3333
if errorlevel 1 goto P2POOL_START_FAILED

echo Waiting for P2Pool synchronization. XMRig starts only after SideChain SYNCHRONIZED.
set /a WAITED=0

:WAIT_FOR_LOG
if exist "%LOG%" goto WAIT_FOR_SYNC
if !WAITED! GEQ 60 goto P2POOL_NO_LOG
ping 127.0.0.1 -n 6 >nul
set /a WAITED+=5
goto WAIT_FOR_LOG

:WAIT_FOR_SYNC
findstr /C:"SideChain SYNCHRONIZED" "%LOG%" >nul 2>&1
if not errorlevel 1 goto START_XMRIG
if !WAITED! GEQ 1200 goto SYNC_TIMEOUT
ping 127.0.0.1 -n 11 >nul
set /a WAITED+=10
goto WAIT_FOR_SYNC

:START_XMRIG
echo P2Pool is synchronized. Starting XMRig...
start "XMRig" /b "%BASE%xmrig.exe" -c "%BASE%config.json"
if errorlevel 1 goto XMRIG_START_FAILED
echo P2Pool and XMRig were started. Keep this window open while mining.
popd
exit /b 0

:MISSING_P2POOL
echo p2pool.exe was not found next to start.bat.
goto FAIL
:MISSING_XMRIG
echo xmrig.exe was not found next to start.bat.
goto FAIL
:MISSING_CONFIG
echo config.json was not found next to start.bat.
goto FAIL
:ALREADY_RUNNING
echo P2Pool is already running. Close it before running start.bat again.
goto FAIL
:LOG_LOCKED
echo Could not reset p2pool.log. Close P2Pool and try again.
goto FAIL
:P2POOL_START_FAILED
echo P2Pool could not be started. Check Windows Security and the P2Pool files.
goto FAIL
:P2POOL_NO_LOG
echo P2Pool did not create its log within 60 seconds. XMRig was not started.
goto FAIL
:SYNC_TIMEOUT
echo SideChain did not synchronize within 20 minutes. XMRig was not started.
echo Check the P2Pool window, network, and the p2pool.log file.
goto FAIL
:XMRIG_START_FAILED
echo XMRig could not be started. Check Windows Security and config.json.
goto FAIL
:FAIL
popd
pause
exit /b 1
