$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$XMRig = Join-Path $Root 'xmrig\xmrig-6.26.0\xmrig.exe'
$StateDir = Join-Path $env:APPDATA 'Gupax'
$State = Join-Path $StateDir 'state.toml'
$Log = Join-Path $Root 'benchmark.log'
if (-not (Test-Path $State)) { New-Item -ItemType Directory -Force -Path $StateDir | Out-Null; Copy-Item (Join-Path $Root 'config\state.toml') $State -Force }
Write-Host 'CPU 속도 측정 중입니다. 첫 실행은 1~3분 걸릴 수 있습니다...'
$lines = @(& $XMRig '--bench=1M' '--no-color' '--donate-level=0' '--print-time=1' 2>&1)
$lines | Out-File -FilePath $Log -Encoding utf8
$matches = [regex]::Matches(($lines -join "`n"), '(?i)([0-9]+(?:\.[0-9]+)?)\s*H/s')
$hashrate = $null
if ($matches.Count -gt 0) { $hashrate = [double]$matches[$matches.Count - 1].Groups[1].Value }
$resultLog = Join-Path $Root 'chain-selection.log'
if ($null -eq $hashrate -or $hashrate -le 0) { $hashrate = 3000.0; Add-Content $resultLog 'Benchmark failed; using conservative 3000 H/s estimate.' }

function Get-PoolInfo($url) {
    try { return Invoke-RestMethod -Uri $url -TimeoutSec 15 } catch { return $null }
}
$main = Get-PoolInfo 'https://p2pool.observer/api/pool_info'
$mini = Get-PoolInfo 'https://mini.p2pool.observer/api/pool_info'
$mainDiff = if ($null -ne $main) { [double]$main.sidechain.difficulty } else { 3700000000.0 }
$miniDiff = if ($null -ne $mini) { [double]$mini.sidechain.difficulty } else { 270000000.0 }
$mainShareHours = $mainDiff / $hashrate / 3600.0
$miniShareHours = $miniDiff / $hashrate / 3600.0
# A share must be in the PPLNS window when a Monero block is found.
# The lower expected share time is the better first-payout choice for low hashrate.
$chain = if ($mainShareHours -lt $miniShareHours) { 'Main' } else { 'Mini' }
$selection = "$(Get-Date -Format o) H/s=$([math]::Round($hashrate,0)) MainDifficulty=$mainDiff MainShareHours=$([math]::Round($mainShareHours,2)) MiniDifficulty=$miniDiff MiniShareHours=$([math]::Round($miniShareHours,2)) Selected=$chain"
Add-Content -LiteralPath $resultLog $selection
$content = Get-Content -Raw -LiteralPath $State
$content = [regex]::Replace($content, '(?m)^chain\s*=\s*"[^"]*"', ('chain = "' + $chain + '"'), 1)
Set-Content -LiteralPath $State -Value $content -Encoding utf8
Write-Host ("선택 결과: {0} | {1:N0} H/s | Main 예상 share {2:N1}시간 | Mini 예상 share {3:N1}시간" -f $chain, $hashrate, $mainShareHours, $miniShareHours)
