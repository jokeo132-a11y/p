@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "gupax\gupax-v2.0.1-windows-x64\Gupax.exe" goto :error
if not exist "p2pool\p2pool-v4.18.1-windows-x64\p2pool.exe" goto :error
if not exist "xmrig\xmrig-6.26.0\xmrig.exe" goto :error
if not exist "%APPDATA%\Gupax" mkdir "%APPDATA%\Gupax"
if not exist "%APPDATA%\Gupax\p2pool" mkdir "%APPDATA%\Gupax\p2pool"
if not exist "%APPDATA%\Gupax\state.toml" copy /Y "config\state.toml" "%APPDATA%\Gupax\state.toml" >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0AUTO-SELECT-P2POOL.ps1"
if errorlevel 1 goto :error
start "Gupax P2Pool" /D "%~dp0" "%~dp0gupax\gupax-v2.0.1-windows-x64\Gupax.exe" --daemon
endlocal
exit /b 0
:error
echo [ERROR] 필요한 파일 또는 설정이 없습니다.
pause
exit /b 1
